namespace MiHoMiao.Migxn.Syntax.Grammars.Expressions.Binary;

/// <summary>
/// 这种二元运算符左右侧表达式应该要紧靠, 不要留空格
/// </summary>
internal interface IClosedBinaryToken : IBinaryToken;
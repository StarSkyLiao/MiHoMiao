namespace MiHoMiao.Migxn.Syntax.Lexers.Tokens.Operators;

internal interface ILeaderOpToken
{
    
    MigxnNode MigxnNode { get; }
}
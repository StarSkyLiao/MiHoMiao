namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Data.Store;

internal class OpDup : MigxnOpCode
{
    public override string ToString() => $"dup";
}
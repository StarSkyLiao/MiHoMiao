namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Data.Load;

internal abstract class OpLdc : MigxnOpCode
{
    
}
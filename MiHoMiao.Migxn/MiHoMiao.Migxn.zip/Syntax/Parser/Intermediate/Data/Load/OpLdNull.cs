namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Data.Load;

internal class OpLdNull : OpLdc
{
    public override string ToString() => $"ld.null";
}
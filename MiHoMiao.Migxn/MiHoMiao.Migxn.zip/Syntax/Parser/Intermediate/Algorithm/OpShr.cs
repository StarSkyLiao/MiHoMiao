namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Algorithm;

internal class OpShr: MigxnOpCode
{
    public override string ToString() => "shr";
}
namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Algorithm;

internal class OpSub: MigxnOpCode
{
    public override string ToString() => "sub";
}
namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Algorithm;

internal class OpMul: MigxnOpCode
{
    public override string ToString() => "mul";
}
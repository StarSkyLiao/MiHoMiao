namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Algorithm;

internal class OpOr: MigxnOpCode
{
    public override string ToString() => "or";
}
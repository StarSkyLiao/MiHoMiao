namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Algorithm;

internal class OpNeg: MigxnOpCode
{
    public override string ToString() => "neg";
}
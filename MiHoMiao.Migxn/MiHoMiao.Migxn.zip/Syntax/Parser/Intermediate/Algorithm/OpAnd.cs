namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Algorithm;

internal class OpAnd: MigxnOpCode
{
    public override string ToString() => "and";
}
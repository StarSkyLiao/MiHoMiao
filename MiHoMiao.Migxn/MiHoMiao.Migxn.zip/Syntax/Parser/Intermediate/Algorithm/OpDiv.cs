namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Algorithm;

internal class OpDiv: MigxnOpCode
{
    public override string ToString() => "div";
}
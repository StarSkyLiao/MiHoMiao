namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Algorithm;

internal class OpXor: MigxnOpCode
{
    public override string ToString() => "xor";
}
namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Algorithm;

internal class OpAdd: MigxnOpCode
{
    public override string ToString() => "add";
}
namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Algorithm;

internal class OpRem: MigxnOpCode
{
    public override string ToString() => "rem";
}
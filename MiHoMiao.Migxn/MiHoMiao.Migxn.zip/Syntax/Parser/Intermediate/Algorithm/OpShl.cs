namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Algorithm;

internal class OpShl: MigxnOpCode
{
    public override string ToString() => "shl";
}
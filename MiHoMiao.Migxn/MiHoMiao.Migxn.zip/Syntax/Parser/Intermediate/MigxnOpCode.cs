namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate;

internal abstract class MigxnOpCode
{
    public abstract override string ToString();
}
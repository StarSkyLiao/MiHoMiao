namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Compare;

internal class OpCle : MigxnOpCode
{
    public override string ToString() => "clt.un\nldc.i4.0\nceq";
}
namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Compare;

internal class OpNeq : MigxnOpCode
{
    public override string ToString() => "ceq\nldc.i4.0\nceq";
}
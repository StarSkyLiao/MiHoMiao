namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Compare;

internal class OpCgt : MigxnOpCode
{
    public override string ToString() => "cgt";
}
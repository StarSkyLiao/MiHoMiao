namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Compare;

internal class OpCeq : MigxnOpCode
{
    public override string ToString() => "ceq";
}
namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Compare;

internal class OpCge : MigxnOpCode
{
    public override string ToString() => "cgt.un\nldc.i4.0\nceq";
}
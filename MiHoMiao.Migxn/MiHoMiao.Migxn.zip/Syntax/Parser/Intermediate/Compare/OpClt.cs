namespace MiHoMiao.Migxn.Syntax.Parser.Intermediate.Compare;

internal class OpClt : MigxnOpCode
{
    public override string ToString() => "clt";
}
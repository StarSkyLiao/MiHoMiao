namespace MiHoMiao.Migxn.Runtime;

public class MigxnFrame
{
    
}
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.Text;

namespace MiHoMiao.Migxn.Analysis.Lexer;

public class RoslynTest
{
    public void Test1()
    {
        TextSpan a;
    }
}